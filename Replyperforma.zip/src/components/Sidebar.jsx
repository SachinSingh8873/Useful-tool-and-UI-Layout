import React from 'react';
import Order from './Order.jsx';
import Profile from './Profile.jsx';
import Settings from './Settings.jsx';
import image from '../assets/image.png';

function Sidebar({ sidebarOpen, handleSidebar, Page, setPage }) {
  const pages = ["CentreDetails", "Superintendent", "AsstSuperintendent", "HeadInstitution", "BankDetails"];
  const currentIndex = pages.indexOf(Page);

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setPage(pages[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (currentIndex < pages.length - 1) {
      setPage(pages[currentIndex + 1]);
    }
  };

  return (
    <div className={`flex flex-col flex-1 transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
      <nav className="px-2 flex items-center justify-between bg-white shadow-md">
        <button className="hover:bg-gray-700 px-3 py-2 rounded" onClick={handleSidebar}>☰</button>
        <div>
          <img src={image} alt="Institute Logo" className="p-0 m-0 flex-1 max-w-xs h-auto object-contain" />
        </div>
        <div>
          <h1 className="text-lg font-bold">The Institute of Company Secretaries of India</h1>
        </div>
      </nav>

      <div className="flex-1 p-6">
        {Page === "CentreDetails" && <Order />}
        {Page === "Superintendent" && <Profile />}
        {Page === "AsstSuperintendent" && <Settings />}
        {Page === "HeadInstitution" && <Settings />}
        {Page === "BankDetails" && <Settings />}
        
        <div className="flex justify-between mt-4">
          {currentIndex > 0 && (
            <button onClick={handlePrevious}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700"
            >
              Previous
            </button>
          )}
          {currentIndex < pages.length - 1 && (
            <button onClick={handleNext}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700"
            >
              Next
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default Sidebar;
