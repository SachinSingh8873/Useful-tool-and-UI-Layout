import React, { useState } from "react";
import Order from "./Order.jsx";
import Profile from "./Profile.jsx";
import Settings from "./Settings.jsx";
import { TiAdjustBrightness } from "react-icons/ti";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import image from '../assets/image.png';
import sidebarimage from '/public/bg.jpg';
import Sidebar from "./Sidebar.jsx";

const Dashboard = () => {
  const pages = ["CentreDetails", "Superintendent", "AsstSuperintendent", "HeadInstitution", "BankDetails"];
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [Page, setPage] = useState("Order");
  const [isLoggedIn, setLoggedin] = useState(false);

  const handleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const currentIndex = pages.indexOf(Page);

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setPage(pages[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (currentIndex < pages.length - 1) {
      setPage(pages[currentIndex + 1]);
    }
  };

  return isLoggedIn ? (
    <>
      <div className="flex">
        {/* Sidebar */}
        <div className={`fixed left-0 mt-16 h-full ${sidebarOpen ? "w-64" : "w-16"} 
          bg-black text-white transition-all duration-300 ease-in-out z-50 overflow-y-auto`}>
          <div className="absolute inset-0 bg-[url('/bg.jpg')] bg-cover bg-center opacity-20"></div>
          <ul className="relative space-y-2 px-2 py-2">
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700 ${Page === "CentreDetails" ? "bg-gray-700" : ""}`} onClick={() => {setPage("CentreDetails"); setSidebarOpen(false)}}>
                <AcUnitIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Centre Details</span>
              </a>
            </li>
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700 ${Page === "Superintendent" ? "bg-gray-700" : ""}`} onClick={() =>{ setPage("Superintendent");setSidebarOpen(false)}}>
                <AccountCircleIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Superintendent</span>
              </a>
            </li>
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700 ${Page === "AsstSuperintendent" ? "bg-gray-700" : ""}`} onClick={() =>{setPage("AsstSuperintendent"); setSidebarOpen(false)}}>
                <SettingsIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Asst. Superintendent</span>
              </a>
            </li>
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700 ${Page === "HeadInstitution" ? "bg-gray-700" : ""}`} onClick={() =>{setPage("HeadInstitution");setSidebarOpen(false)}}>
                <SettingsIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Head Of the Institution</span>
              </a>
            </li>
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700`} onClick={() => {setPage("BankDetails");setSidebarOpen(false)}}>
                <SettingsIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Bank Details</span>
              </a>
            </li>
            <li>
              <a className={`flex items-center p-2 rounded hover:bg-gray-700`} onClick={() => {setLoggedin(false);setSidebarOpen(false)}}>
                <LogoutIcon className="mr-2" />
                <span className={`${sidebarOpen ? "inline" : "hidden"}`}>Logout</span>
              </a>
            </li>
          </ul>
        </div>
        <Sidebar  sidebarOpen={sidebarOpen} handleSidebar={handleSidebar} Page={Page} setPage={setPage}/>
        {/* <div className={`flex flex-col flex-1 transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
          <nav className="px-2 flex items-center justify-between bg-white shadow-md">
            <button className="hover:bg-gray-700 px-3 py-2 rounded" onClick={handleSidebar}>☰</button>
            <div><img src={image} alt="image" className="p-0 m-0 flex-1 max-w-xs h-auto object-contain" /></div>
            <div><h1 className="text-lg font-bold">The Institute of Company Secreatory of India</h1></div>
          </nav>
        
          <div className="flex-1 p-6">
            {Page === "CentreDetails" && <Order />}
            {Page === "Superintendent" && <Profile />}
            {Page === "AsstSuperintendent" && <Settings />}
            {Page === "HeadInstitution" && <Settings />}
            {Page === "BankDetails" && <Settings />}
            {currentIndex > 0 && (
              <button
                onClick={handlePrevious}
                className="mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700"
              >
                Previous
              </button>
            )}
            {currentIndex < pages.length - 1 && (
              <button
                onClick={handleNext}
                className="mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700"
              >
                Next
              </button>
            )}
          </div>
        </div> */}
      </div>
    </>
  ) : (
    <div className="m-auto p-5 text-bold">
      This is not logged in 
      <button className="bg-gray-500 p-2" style={{ border: '2px solid black' }} onClick={() => setLoggedin(true)}>Click here to login</button>
    </div>
  );
};

export default Dashboard;