import React from 'react'

function Settings() {
  return (
    <div>This is Settings</div>
  )
}

export default Settings