import React from 'react'

function Order() {
  return (
  <>
  <center>
  <h2>Dashboard</h2>
  </center>
    
    <div>This is dhiru bhai ambani</div>
  </>
  )
}

export default Order