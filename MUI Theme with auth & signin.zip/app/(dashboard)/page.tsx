import * as React from 'react';
import DashboardContent from './DashboardContent';

export default function Dashboard() {
  return <DashboardContent />;
}
