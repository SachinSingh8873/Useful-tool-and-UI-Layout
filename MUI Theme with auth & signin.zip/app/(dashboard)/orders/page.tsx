'use client';
import * as React from 'react';
import CustomDataGrid from '../../components/CustomDataGrid';

export default function OrdersPage() {
  return <CustomDataGrid />;
}
