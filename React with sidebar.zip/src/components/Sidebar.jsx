import React, { useEffect } from "react";
import AcUnitIcon from "@mui/icons-material/AcUnit";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import BusinessIcon from "@mui/icons-material/Business";
import LocalAtmIcon from "@mui/icons-material/LocalAtm";

const Sidebar = ({ sidebarOpen, handleSidebar, Page, setPage,setLoggedin,setSidebarOpen }) => {
const handlelogout=()=>{
  setLoggedin(false);
}

const handlemobile =() =>{
  if(window.innerWidth<768){
    setSidebarOpen(false);
  }
  else{
    setSidebarOpen(true);
  }
}

  return (
    // <div
    //   className={`fixed left-0 md:mt-25 mt-26 h-full rounded ${
    //     sidebarOpen ? "w-64" : "sm:w-18 p-2 sm:block hidden"
    //   } bg-black text-white transition-all duration-300 ease-in-out z-40`}
    // >
    <div
      className={`fixed left-0 md:mt-25 mt-26 h-full rounded bg-black text-white z-40 transition-all duration-500 ease-in-out transform ${
        sidebarOpen ? "w-64 translate-x-0" : " -translate-x-full p-1 sm:w-18 sm:translate-x-0"}`}
    >
      <div className="absolute inset-0 bg-[url('/bg.jpg')] bg-cover bg-center opacity-10 pointer-events-none"></div>
      <ul className="space-y-2 px-2 py-2">
        <li>
          <button
            className={`transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700
               ${Page === "CentreDetails" ? "bg-gray-700" : ""}`}
            onClick={() => {setPage("CentreDetails"); handlemobile();}}>
            <AcUnitIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`}>
              Centre Details
            </span>
          </button>
        </li>
        <li>
          <button
            className={`transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700
               ${Page === "Superintendent" ? "bg-gray-700" : ""}`}
            onClick={() => {setPage("Superintendent");handlemobile();}}
          >
            <AccountCircleIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`}>
              Superintendent
            </span>
          </button>
        </li>
        <li>
          <button
            className={`transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700 ${
              Page === "AsstSuperintendent" ? "bg-gray-700" : ""
            }`}
            onClick={() => {setPage("AsstSuperintendent");handlemobile();}}
          >
            <SettingsIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`}>
              Asst. Superintendent
            </span>
          </button>
        </li>
        <li>
          <button
            className={`transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700 ${
              Page === "HeadInstitution" ? "bg-gray-700" : ""
            }`}
            onClick={() => {setPage("HeadInstitution");handlemobile();}}
          >
            <BusinessIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`}>
              Head of Institution
            </span>
          </button>
        </li>
        <li>
          <button
            className={`transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700 ${
              Page === "BankDetails" ? "bg-gray-700" : ""
            }`}
            onClick={() => {setPage("BankDetails");handlemobile();}}
          >
            <LocalAtmIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`}>
              Bank Details
            </span>
          </button>
        </li>
        <li>
          <button
            className="transition-all duration-300 ease-in-out flex items-center p-2 rounded w-full text-left hover:bg-gray-700"
            onClick={() => {handleSidebar(false);handlelogout();}}
          >
            <LogoutIcon className="mr-2" />
            <span className={`transition-all duration-300 ${sidebarOpen ? "inline" : "hidden"}`} >
              Logout
            </span>
          </button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
