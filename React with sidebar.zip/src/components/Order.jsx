import React from 'react'

function Order() {
  return (
  <>
  <center>
  <h1 className='text-2xl font-bold'>Dashboard</h1>
  </center>

    <div>This is dhiru bhai ambani</div>
    <div>Hello guys</div>

  <table className='border-2 border-solid p-2'>
      <tr className='border-2 border-solid p-2'>
        <td className='border-2 border-solid p-2'>Name</td>
        <td className='border-2 border-solid p-2'>Roll</td>
        <td className='border-2 border-solid p-2'>Class</td>
      </tr>
      <tr>
        <td className='border-2 border-solid'>Sachin</td>
        <td className='border-2 border-solid'>19</td>
        <td className='border-2 border-solid'>MCA</td>
      </tr>
    </table>
  </>
  )
}

export default Order