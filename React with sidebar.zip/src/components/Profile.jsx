import React from 'react'

function Profile() {
  return (
    <div>This is Profile</div>
  )
}

export default Profile