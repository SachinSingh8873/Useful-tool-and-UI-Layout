import React, { useState } from "react";
import Order from "./Order.jsx";
import Profile from "./Profile.jsx";
import Settings from "./Settings.jsx";
import Sidebar from "./Sidebar.jsx";
import image from "../assets/image.png";

const Dashboard = () => {
  const pages = ["CentreDetails", "Superintendent", "AsstSuperintendent", "HeadInstitution", "BankDetails"];
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [Page, setPage] = useState("CentreDetails");
  const [isLoggedIn, setLoggedin] = useState(true);

  const handleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const currentIndex = pages.indexOf(Page);

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setPage(pages[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (currentIndex < pages.length - 1) {
      setPage(pages[currentIndex + 1]);
    }
  };

  return isLoggedIn ? (
    <>
      {/* Navbar */}
      <nav className="fixed top-0 left-0 w-full h-25 bg-white shadow-md flex items-center px-4  z-50">
        <button className="hover:bg-gray-200 px-3 py-2 rounded" onClick={handleSidebar}>
          ☰
        </button>
        <img src={image} alt="Institute Logo" className="flex-initial h-25 w-74 object-cover" />
        <h1 className="text-lg font-bold flex-none sm:block hidden">The Institute of Company Secretaries of India</h1>
      </nav>

      {/* Sidebar and Content Wrapper */}
      <div className="flex h-screen mt-auto ">
        {/* Sidebar (Placed Below Navbar) */}
        <Sidebar sidebarOpen={sidebarOpen} handleSidebar={handleSidebar} Page={Page} setPage={setPage} setLoggedin={setLoggedin} setSidebarOpen={setSidebarOpen}/>

        {/* Main Content */}
        {/* <div className={`max-w-screen-sm flex flex-col flex-1 transition-all mt-20 duration-300 ${sidebarOpen ? "ml-64" : "md:ml-16 ml-0"}`}> */}
        <div className={`flex-1 transition-all mt-20 duration-300 ${sidebarOpen ? "sm:ml-64 sm:w-[calc(100%-16rem)] w-full" : "md:ml-16 ml-0 w-full"}`}>
          <div className="flex-1 p-6">
            {Page === "CentreDetails" && <Order />}
            {Page === "Superintendent" && <Profile />}
            {Page === "AsstSuperintendent" && <Settings />}
            {Page === "HeadInstitution" && <Settings />}
            {Page === "BankDetails" && <Settings />}

            {/* Navigation Buttons */}
            <div className="mt-4 flex flex-col sm:flex-row gap-2">
              {currentIndex > 0 && (
                <button onClick={handlePrevious} className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700">
                  Previous
                </button>
              )}
              {currentIndex < pages.length - 1 && (
                <button onClick={handleNext} className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-700">
                  Next
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  ) : (
    <div className="flex flex-col items-center justify-center h-screen">
      <p className="text-lg font-bold">This is not logged in</p>
      <button className="bg-gray-500 p-2 mt-3 text-white rounded hover:bg-gray-700" onClick={() => setLoggedin(true)}>
        Click here to login
      </button>
    </div>
  );
};

export default Dashboard;
